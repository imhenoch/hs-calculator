module Calculadora where
import Trigoradianes
import Trigogrados
import Logaritmicas
import Algebraicas
import Exponencial

